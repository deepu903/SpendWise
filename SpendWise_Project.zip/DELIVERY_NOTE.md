# Project Delivery Note: SpendWise AI

## Overview
SpendWise AI is a specialized finance-tech tool designed for startups to audit and optimize their AI software subscriptions. It surfaces immediate savings by mapping current tool usage against team requirements and suggesting cost-effective alternatives or plan adjustments.

## How to Get Started
To run this project locally, follow these steps:

1. **Unzip the contents** to your desired directory.
2. **Install Dependencies**:
   ```bash
   npm install
   ```
3. **Run Development Server**:
   ```bash
   npm run dev
   ```
4. **Access the App**: Open [http://localhost:3000](http://localhost:3000) in your browser.

## Current State & Features
- **Deterministic Audit Engine**: A robust rules engine that calculates potential savings based on industry pricing data.
- **Dynamic Multi-step Form**: Responsive audit form for capturing user data and current AI tool stack.
- **Results Dashboard**: A high-impact visualization of savings, recommended plan changes, and projected annual ROI.
- **Dark-Mode-First Design**: Modern, premium aesthetic optimized for finance and tech audiences.
- **Lead Capture Integration**: Integrated flow for capturing potential customer interest.

## Technical Details
- **Framework**: Next.js 15 (App Router)
- **Styling**: Tailwind CSS + Custom Vanilla CSS
- **State Management**: React Hooks + Local/Session Storage for performance and speed.
- **Exclusions**: The provided ZIP file excludes `node_modules`, `.next` build files, and `.git` history to minimize file size.

---
*Created by Antigravity AI*
